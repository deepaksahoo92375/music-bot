import asyncio
from config import Config
from music.queue import Track,TrackQueue
from web.auth import verify_telegram_login

def test_queue():
 q=TrackQueue(2); q.add(Track("a","u")); q.add(Track("b","v")); assert len(q)==2; assert q.pop().title=="a"

def test_config_validation():
 c=Config(1,"h","t",2,["s"]); assert c.validate()==[]

def test_auth_rejects_missing(): assert verify_telegram_login({},"token") is False
