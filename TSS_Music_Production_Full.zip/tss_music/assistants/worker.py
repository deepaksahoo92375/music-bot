from __future__ import annotations
import inspect, logging, time
try:
    from pyrogram import Client
except Exception: Client=None
try:
    from pytgcalls import PyTgCalls
except Exception: PyTgCalls=None

log=logging.getLogger(__name__)

async def maybe_await(value):
    return await value if inspect.isawaitable(value) else value

class AssistantWorker:
    def __init__(self,index,session,api_id,api_hash):
        self.index=index; self.session=session; self.api_id=api_id; self.api_hash=api_hash
        self.client=None; self.calls=None; self.online=False; self.errors=0; self.voice_chats=0
        self.last_heartbeat=0; self.maintenance=False
    async def start(self):
        if not self.session: return False
        if Client is None: raise RuntimeError("kurigram is not installed")
        self.client=Client(f"sessions/assistant_{self.index}",api_id=self.api_id,api_hash=self.api_hash,session_string=self.session,in_memory=True)
        await maybe_await(self.client.start()); self.online=True; self.last_heartbeat=time.time()
        if PyTgCalls is None: raise RuntimeError("py-tgcalls is not installed")
        self.calls=PyTgCalls(self.client); await maybe_await(self.calls.start())
        return True
    async def stop(self):
        self.online=False
        if self.calls:
            try: await maybe_await(self.calls.stop())
            except Exception: log.exception("Assistant %s call stop failed",self.index)
        if self.client:
            try: await maybe_await(self.client.stop())
            except Exception: pass
    async def play(self, chat_id, stream):
        if not self.calls: raise RuntimeError("PyTgCalls is not started")
        self.voice_chats=max(self.voice_chats,1)
        try: return await maybe_await(self.calls.play(chat_id, stream))
        except Exception: self.errors+=1; raise
    async def pause(self,chat_id): return await maybe_await(self.calls.pause(chat_id))
    async def resume(self,chat_id): return await maybe_await(self.calls.resume(chat_id))
    async def leave(self,chat_id):
        for name in ("leave_call","leave_group_call","stop"):
            fn=getattr(self.calls,name,None) if self.calls else None
            if fn:
                try: return await maybe_await(fn(chat_id))
                except TypeError: continue
        return None
    def score(self): return self.voice_chats*5+self.errors*2
