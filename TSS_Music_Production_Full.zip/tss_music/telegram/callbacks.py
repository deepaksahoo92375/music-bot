from pyrogram import filters
async def register_callbacks(bot, supervisor):
    @bot.on_callback_query(filters.regex(r"^start:"))
    async def start(_,q):
        target=int(q.data.split(":",1)[1])
        try:
            t=await supervisor.play_next(target); await q.answer("Started" if t else "Queue empty")
            if t: await q.message.edit_text(f"🎵 NOW PLAYING\n\n{t.title}\n{t.artist}\n\nMode: {t.media_type.upper()}\nQueue: {len(supervisor.state(target).queue)}")
        except Exception as e: await q.answer(f"Playback unavailable: {type(e).__name__}",show_alert=True)
