from pyrogram import filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def register_handlers(bot, supervisor, stats, owner_id):
    @bot.on_message(filters.command("start"))
    async def start(_,m): await m.reply_text("🎧 TSS Music is online.\nUse /play <song> for audio or /vdplay <song> for video.")
    async def request(m,video=False):
        if len(m.command)<2:return await m.reply_text("Usage: /vdplay <query or URL>" if video else "Usage: /play <query or URL>")
        q=m.text.split(None,1)[1]
        try:
            t=await supervisor.enqueue(m.chat.id,q,m.from_user.id,m.from_user.first_name or "User",video)
            await stats.inc("requests")
            await m.reply_text(("🎬" if video else "🎵")+f" Queued: {t.title}\nMode: {'VIDEO' if video else 'AUDIO'}\nQueue: {len(supervisor.state(m.chat.id).queue)}",reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("▶️ Start",callback_data=f"start:{m.chat.id}")]]))
        except Exception as e: await m.reply_text(f"❌ Unable to queue media: {type(e).__name__}")
    @bot.on_message(filters.command("play"))
    async def play(_,m): await request(m,False)
    @bot.on_message(filters.command("vdplay"))
    async def vdplay(_,m): await request(m,True)
    @bot.on_message(filters.command("queue"))
    async def queue(_,m):
        p=supervisor.state(m.chat.id); await m.reply_text("📜 Queue is empty." if not p.queue.items else "📜\n"+"\n".join(f"{i+1}. {x.title}" for i,x in enumerate(p.queue.items[:20])))
    @bot.on_message(filters.command("pause"))
    async def pause(_,m):
        try: await supervisor.pause(m.chat.id); await m.reply_text("⏸ Paused.")
        except Exception as e: await m.reply_text(f"❌ Pause failed: {type(e).__name__}")
    @bot.on_message(filters.command("resume"))
    async def resume(_,m):
        try: await supervisor.resume(m.chat.id); await m.reply_text("▶️ Resumed.")
        except Exception as e: await m.reply_text(f"❌ Resume failed: {type(e).__name__}")
    @bot.on_message(filters.command("skip"))
    async def skip(_,m):
        try:
            t=await supervisor.skip(m.chat.id); await m.reply_text(f"⏭ {t.title}" if t else "Queue empty.")
        except Exception as e: await m.reply_text(f"❌ Skip failed: {type(e).__name__}")
    @bot.on_message(filters.command("shuffle"))
    async def shuffle(_,m): supervisor.state(m.chat.id).queue.shuffle_queue(); await m.reply_text("🔀 Queue shuffled.")
    @bot.on_message(filters.command("clear"))
    async def clear(_,m): supervisor.state(m.chat.id).queue.clear(); await m.reply_text("🧹 Queue cleared.")
    @bot.on_message(filters.command("stop"))
    async def stop(_,m): await supervisor.stop(m.chat.id); await m.reply_text("⏹ Player stopped and queue cleared.")
    @bot.on_message(filters.command("nowplaying"))
    async def now(_,m):
        p=supervisor.state(m.chat.id); await m.reply_text("🎵 Nothing is playing." if not p.current else f"🎵 {p.current.title}\nMode: {p.current.media_type.upper()}\nQueue: {len(p.queue)}")
