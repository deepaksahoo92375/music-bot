import importlib, shutil, sys
mods=["config","core.assistant_manager","core.player_supervisor","music.queue","music.resolver","web.app"]
for m in mods: importlib.import_module(m)
print("Python imports: OK")
print("FFmpeg:",shutil.which("ffmpeg") or "NOT FOUND (required at runtime)")
print("yt-dlp:",shutil.which("yt-dlp") or "Python module required")
print("Preflight complete")
