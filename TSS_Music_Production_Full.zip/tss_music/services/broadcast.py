import asyncio, logging
log=logging.getLogger(__name__)
class BroadcastService:
    def __init__(self,bot): self.bot=bot
    async def send(self,chat_ids,text):
        result={"successful":0,"failed":0}
        for cid in chat_ids:
            try: await self.bot.send_message(cid,text); result["successful"]+=1
            except Exception as e: result["failed"]+=1; log.warning("Broadcast failed for %s: %s",cid,type(e).__name__)
            await asyncio.sleep(0.05)
        return result
