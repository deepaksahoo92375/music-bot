class Statistics:
    def __init__(self,db): self.db=db
    async def inc(self,name,amount=1): await self.db.incr(name,amount)
    async def snapshot(self): return await self.db.stats()
