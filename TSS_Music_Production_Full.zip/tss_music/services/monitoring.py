import psutil, time
class Monitor:
    def snapshot(self):
        vm=psutil.virtual_memory(); d=psutil.disk_usage("/"); n=psutil.net_io_counters()
        return {"cpu":psutil.cpu_percent(interval=None),"ram_percent":vm.percent,"ram_gb":round(vm.used/1024**3,2),"disk_percent":d.percent,"disk_free_gb":round(d.free/1024**3,2),"net_sent":n.bytes_sent,"net_recv":n.bytes_recv,"uptime":int(time.time()-psutil.boot_time())}
