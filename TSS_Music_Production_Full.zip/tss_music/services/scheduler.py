import asyncio, logging
log=logging.getLogger(__name__)
class Scheduler:
    def __init__(self): self.tasks=[]
    def add(self,coro_factory,seconds): self.tasks.append(asyncio.create_task(self._loop(coro_factory,seconds)))
    async def _loop(self,f,seconds):
        while True:
            try: await f()
            except asyncio.CancelledError: raise
            except Exception: log.exception("Scheduled job failed")
            await asyncio.sleep(seconds)
    async def stop(self):
        for t in self.tasks: t.cancel()
        await asyncio.gather(*self.tasks,return_exceptions=True)
