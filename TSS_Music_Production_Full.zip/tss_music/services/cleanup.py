from __future__ import annotations
import os, time
from pathlib import Path
class CacheCleaner:
    def __init__(self,cache_dir,max_gb,min_free_gb): self.cache_dir=Path(cache_dir); self.max_bytes=max_gb*1024**3; self.min_free=min_free_gb*1024**3
    def cleanup(self):
        files=[p for p in self.cache_dir.rglob("*") if p.is_file()]; total=sum(p.stat().st_size for p in files)
        free=os.statvfs(self.cache_dir).f_bavail*os.statvfs(self.cache_dir).f_frsize
        if total<=self.max_bytes and free>=self.min_free:return 0
        removed=0
        for p in sorted(files,key=lambda x:x.stat().st_mtime):
            try: size=p.stat().st_size; p.unlink(); removed+=size; total-=size
            except OSError: pass
            if total<=self.max_bytes and free+removed>=self.min_free: break
        return removed
