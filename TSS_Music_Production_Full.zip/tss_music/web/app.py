from __future__ import annotations
from aiohttp import web
from .auth import verify_telegram_login
import json

def create_web_app(config, supervisor, assistant_manager, monitor, stats):
    app=web.Application(); routes=web.RouteTableDef()
    @routes.get("/health")
    async def health(request): return web.json_response({"status":"ok","bot":"online","assistants":len(assistant_manager.workers),"active_players":len(supervisor.registry.players)})
    @routes.get("/")
    async def index(request): return web.FileResponse("web/templates/index.html")
    @routes.get("/api/status")
    async def status(request):
        return web.json_response({"system":monitor.snapshot(),"assistants":assistant_manager.snapshot(),"players":supervisor.snapshot(),"statistics":await stats.snapshot()})
    @routes.post("/auth/telegram")
    async def telegram_auth(request):
        data=await request.post(); payload=dict(data)
        if not verify_telegram_login(payload,config.bot_token): return web.json_response({"ok":False},status=401)
        if int(payload.get("id",0))!=config.owner_id: return web.json_response({"ok":False},status=403)
        return web.json_response({"ok":True,"user_id":int(payload["id"])})
    app.add_routes(routes); return app
