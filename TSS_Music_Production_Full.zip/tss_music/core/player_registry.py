class PlayerRegistry:
    def __init__(self): self.players={}
    def get(self,target_id): return self.players.get(int(target_id))
    def set(self,target_id,player): self.players[int(target_id)]=player
    def remove(self,target_id): self.players.pop(int(target_id),None)
    def all(self): return list(self.players.values())
