from __future__ import annotations
import asyncio, logging
from assistants.worker import AssistantWorker
log=logging.getLogger(__name__)
class AssistantManager:
    def __init__(self,config): self.config=config; self.workers={}; self.lock=asyncio.Lock()
    async def start(self):
        for i,s in enumerate(self.config.assistant_sessions,1):
            if not s: continue
            w=AssistantWorker(i,s,self.config.api_id,self.config.api_hash); self.workers[i]=w
            try: await w.start()
            except Exception: log.exception("Assistant %s failed to start",i)
    async def stop(self): await asyncio.gather(*(w.stop() for w in self.workers.values()),return_exceptions=True)
    def choose(self, exclude=None):
        candidates=[w for w in self.workers.values() if w.online and not w.maintenance and w.index!=exclude]
        return min(candidates,key=lambda x:x.score(),default=None)
    def snapshot(self):
        return [{"id":w.index,"online":w.online,"voice_chats":w.voice_chats,"errors":w.errors,"score":w.score()} for w in self.workers.values()]
