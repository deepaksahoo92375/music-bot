from __future__ import annotations
import asyncio, logging
from .player_registry import PlayerRegistry
from .locks import LockRegistry
from music.queue import TrackQueue
from music.resolver import YTDLPResolver
from music.player import MediaPlayer
log=logging.getLogger(__name__)
class PlayerState:
    def __init__(self,target_id,limit=100): self.target_id=target_id; self.queue=TrackQueue(limit); self.mode="audio"; self.assistant=None; self.current=None; self.player=None; self.paused=False
class PlayerSupervisor:
    def __init__(self,config,assistant_manager,repository):
        self.config=config; self.assistant_manager=assistant_manager; self.repo=repository; self.registry=PlayerRegistry(); self.locks=LockRegistry(); self.resolver=YTDLPResolver()
    def state(self,target_id):
        p=self.registry.get(target_id)
        if not p: p=PlayerState(target_id,self.config.max_group_queue); self.registry.set(target_id,p)
        return p
    async def enqueue(self,target_id,query,user_id,user_name,video=False):
        async with self.locks.get(target_id):
            p=self.state(target_id); t=await self.resolver.search_or_url(query,user_id,user_name,"video" if video else "audio"); p.queue.add(t)
            await self.repo.save_player(target_id,{"queue":p.queue.to_dict(),"mode":p.mode}); return t
    async def play_next(self,target_id):
        async with self.locks.get(target_id):
            p=self.state(target_id)
            if p.current: return p.current
            t=p.queue.pop()
            if not t:return None
            a=self.assistant_manager.choose(p.assistant)
            if not a: raise RuntimeError("No healthy assistant available")
            p.assistant=a.index; p.current=t; p.mode=t.media_type
            p.player=MediaPlayer(a,self.resolver)
            try: await p.player.start(target_id,t)
            except Exception:
                a.errors+=1; p.current=None; p.queue.items.insert(0,t); raise
            await self.repo.save_player(target_id,{"queue":p.queue.to_dict(),"mode":p.mode,"assistant":p.assistant,"current":t.to_dict()}); return t
    async def pause(self,target_id):
        async with self.locks.get(target_id):
            p=self.state(target_id)
            if p.player and p.current: await p.player.pause(target_id); p.paused=True
    async def resume(self,target_id):
        async with self.locks.get(target_id):
            p=self.state(target_id)
            if p.player and p.current: await p.player.resume(target_id); p.paused=False
    async def skip(self,target_id):
        async with self.locks.get(target_id):
            p=self.state(target_id)
            if p.player: await p.player.stop(target_id)
            p.current=None; p.player=None
        return await self.play_next(target_id)
    async def stop(self,target_id):
        async with self.locks.get(target_id):
            p=self.state(target_id)
            if p.player:
                try: await p.player.stop(target_id)
                except Exception: log.exception("Stop failed")
            p.current=None; p.player=None; p.queue.clear(); await self.repo.save_player(target_id,{"queue":p.queue.to_dict(),"mode":p.mode})
    def snapshot(self): return [{"target_id":p.target_id,"queue":len(p.queue),"mode":p.mode,"assistant":p.assistant,"current":getattr(p.current,"title",None),"paused":p.paused} for p in self.registry.all()]
