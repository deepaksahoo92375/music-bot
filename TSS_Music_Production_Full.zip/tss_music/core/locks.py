import asyncio
from collections import defaultdict
class LockRegistry:
    def __init__(self): self._locks=defaultdict(asyncio.Lock)
    def get(self,key): return self._locks[key]
