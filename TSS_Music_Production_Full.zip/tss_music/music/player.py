from __future__ import annotations
import logging
from pytgcalls.types import MediaStream, AudioQuality, VideoQuality

log=logging.getLogger(__name__)

class MediaPlayer:
    def __init__(self, assistant, resolver): self.assistant=assistant; self.resolver=resolver; self.current=None; self.paused=False
    def stream(self,track):
        if track.media_type=="video":
            return MediaStream(track.stream_url or track.url, AudioQuality.HIGH, VideoQuality.HD_720p)
        return MediaStream(track.stream_url or track.url, AudioQuality.HIGH, VideoQuality.HD_720p, video_flags=MediaStream.Flags.IGNORE)
    async def start(self,chat_id,track):
        if not track.stream_url: await self.resolver.stream_url(track)
        await self.assistant.play(chat_id,self.stream(track)); self.current=track; self.paused=False
    async def pause(self,chat_id): await self.assistant.pause(chat_id); self.paused=True
    async def resume(self,chat_id): await self.assistant.resume(chat_id); self.paused=False
    async def stop(self,chat_id): await self.assistant.leave(chat_id); self.current=None; self.paused=False
