from __future__ import annotations
import asyncio, yt_dlp
from .queue import Track

class YTDLPResolver:
    def __init__(self):
        self.base={"quiet":True,"no_warnings":True,"noplaylist":True,"skip_download":True,"extract_flat":False}
    async def search_or_url(self, query: str, requester_id=0, requester_name="", media_type="audio") -> Track:
        opts=dict(self.base); opts["format"]="bestaudio/best" if media_type=="audio" else "bestvideo*+bestaudio/best"
        if not (query.startswith("http://") or query.startswith("https://")): query=f"ytsearch1:{query}"
        def work():
            with yt_dlp.YoutubeDL(opts) as ydl:
                info=ydl.extract_info(query, download=False)
                if "entries" in info: info=next((x for x in info["entries"] if x), None)
                if not info: raise RuntimeError("No media found")
                return info
        info=await asyncio.to_thread(work)
        return Track(title=info.get("title","Unknown"),url=info.get("webpage_url") or query,duration=float(info.get("duration") or 0),
                     artist=info.get("artist") or info.get("uploader") or "",thumbnail=info.get("thumbnail") or "",
                     source="youtube",requester_id=requester_id,requester_name=requester_name,media_type=media_type)
    async def stream_url(self, track: Track):
        opts={"quiet":True,"no_warnings":True,"noplaylist":True,"format":"bestaudio/best" if track.media_type=="audio" else "bestvideo*+bestaudio/best"}
        def work():
            with yt_dlp.YoutubeDL(opts) as ydl:
                i=ydl.extract_info(track.url,download=False)
                return i.get("url")
        track.stream_url=await asyncio.to_thread(work); return track
