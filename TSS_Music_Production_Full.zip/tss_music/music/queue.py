from __future__ import annotations
from dataclasses import dataclass, asdict
import random, time

@dataclass
class Track:
    title: str; url: str; duration: float=0; artist: str=""; thumbnail: str=""; source: str="youtube"
    requester_id: int=0; requester_name: str=""; media_type: str="audio"; stream_url: str=""
    requested_at: float=0
    def __post_init__(self): self.requested_at = self.requested_at or time.time()
    def to_dict(self): return asdict(self)
    @classmethod
    def from_dict(cls,d): return cls(**d)

class TrackQueue:
    def __init__(self, limit=100): self.items=[]; self.limit=limit; self.repeat="off"; self.shuffle=False
    def add(self,t):
        if len(self.items)>=self.limit: raise ValueError("Queue limit reached")
        self.items.append(t)
    def pop(self): return self.items.pop(0) if self.items else None
    def clear(self): self.items.clear()
    def shuffle_queue(self): random.shuffle(self.items)
    def __len__(self): return len(self.items)
    def to_dict(self): return {"items":[x.to_dict() for x in self.items],"repeat":self.repeat,"shuffle":self.shuffle}
    @classmethod
    def from_dict(cls,d,limit=100):
        q=cls(limit); q.items=[Track.from_dict(x) for x in d.get("items",[])]; q.repeat=d.get("repeat","off"); q.shuffle=d.get("shuffle",False); return q
