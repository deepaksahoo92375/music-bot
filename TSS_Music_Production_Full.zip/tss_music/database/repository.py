class Repository:
    def __init__(self, db): self.db=db
    async def save_player(self, target_id, state): await self.db.set("player", str(target_id), state)
    async def load_player(self, target_id): return await self.db.get("player", str(target_id))
    async def save_settings(self, target_id, settings): await self.db.set("settings", str(target_id), settings)
    async def load_settings(self, target_id): return await self.db.get("settings", str(target_id)) or {}
