from __future__ import annotations
import sqlite3, asyncio, json
from pathlib import Path

class Database:
    def __init__(self, url: str):
        path = url.removeprefix("sqlite:///") if url.startswith("sqlite:///") else "data/tss_music.db"
        self.path = Path(path); self.path.parent.mkdir(parents=True, exist_ok=True); self.conn=None
        self.lock=asyncio.Lock()
    async def connect(self):
        self.conn=sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory=sqlite3.Row
        await self.execute("""CREATE TABLE IF NOT EXISTS kv (namespace TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, PRIMARY KEY(namespace,key))""")
        await self.execute("""CREATE TABLE IF NOT EXISTS stats (name TEXT PRIMARY KEY, value INTEGER NOT NULL DEFAULT 0)""")
        await self.execute("""CREATE TABLE IF NOT EXISTS admins (telegram_id INTEGER PRIMARY KEY, role TEXT NOT NULL)""")
    async def execute(self, sql, params=()):
        async with self.lock:
            cur=self.conn.execute(sql, params); self.conn.commit(); return cur
    async def get(self, namespace, key):
        cur=await self.execute("SELECT value FROM kv WHERE namespace=? AND key=?",(namespace,key)); row=cur.fetchone()
        return json.loads(row[0]) if row else None
    async def set(self, namespace,key,value):
        await self.execute("INSERT INTO kv(namespace,key,value) VALUES(?,?,?) ON CONFLICT(namespace,key) DO UPDATE SET value=excluded.value",(namespace,key,json.dumps(value)))
    async def incr(self,name,amount=1):
        await self.execute("INSERT INTO stats(name,value) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET value=value+excluded.value",(name,amount))
    async def stats(self):
        cur=await self.execute("SELECT name,value FROM stats"); return {r[0]:r[1] for r in cur.fetchall()}
    async def close(self):
        if self.conn: self.conn.close()
